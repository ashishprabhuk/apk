// the consts defined here should be unique from one another
export const dimensionsMargin = "margin";
export const dimensionsPadding = "padding";
