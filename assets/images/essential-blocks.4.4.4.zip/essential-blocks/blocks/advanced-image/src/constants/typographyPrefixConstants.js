// the consts defined here should be unique from one another
export const typoPrefix_title = "title";
export const typoPrefix_text = "text";
