export const wrpBdShadow = "wrp_";
