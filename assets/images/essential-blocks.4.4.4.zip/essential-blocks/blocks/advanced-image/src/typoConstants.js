export const CAPTION_TYPOGRAPHY = "captionTypo";
