<?php return array('dependencies' => array(), 'version' => '38ca5b2bf12d0d77f2c2');
