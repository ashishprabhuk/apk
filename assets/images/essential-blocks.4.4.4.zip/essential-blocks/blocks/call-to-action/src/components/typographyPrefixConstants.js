export const typoPrefix_title = "title";
export const typoPrefix_subtitle = "subtitle";
export const typoPrefix_desc = "desc";
export const typoPrefix_btn = "btn";