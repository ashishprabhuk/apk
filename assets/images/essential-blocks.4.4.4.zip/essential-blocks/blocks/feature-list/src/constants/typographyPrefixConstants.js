export const typoPrefix_title = "titleText";
export const typoPrefix_content = "contentText";
