// each and every const here has to be totally unique from one another

export const LABEL_TYPOGRAPHY = "label_";
export const CHECKBOX_TEXT = "checkboxText_";
