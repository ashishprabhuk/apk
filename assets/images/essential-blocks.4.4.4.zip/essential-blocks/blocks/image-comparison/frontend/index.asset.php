<?php return array('dependencies' => array('react', 'wp-element'), 'version' => 'bf6557eb500b4ad87556');
