export const typoPrefix_label = "labelText";
