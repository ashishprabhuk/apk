// each and every const here has to be totally unique from one another
export const flipboxFrontWrapper = "front_wrapper_";
export const flipboxBackWrapper = "back_wrapper_";
