<?php return array('dependencies' => array(), 'version' => 'b07302e084a1e3c37b23');
