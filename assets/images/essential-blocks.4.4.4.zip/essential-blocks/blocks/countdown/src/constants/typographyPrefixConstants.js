// each and every const here has to be totally unique from one another

export const typoPrefix_digits = "dg_";
export const typoPrefix_labels = "lb_";
export const typoPrefix_separator = "sp_";
