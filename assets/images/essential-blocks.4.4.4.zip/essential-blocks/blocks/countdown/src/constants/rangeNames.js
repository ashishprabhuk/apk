// each and every const here has to be totally unique from one another

export const wrapperWidth = "wrpW_";
export const boxsSpaceConst = "boxsSpb_";
export const separatorPosTop = "sepTop_";
export const separatorPosRight = "sepRight_";
