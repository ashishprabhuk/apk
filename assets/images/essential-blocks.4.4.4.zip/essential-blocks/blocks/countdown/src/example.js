const example = {
	attributes: {
		endTimeStamp: Date.now() + 462878000,
	},
};

export default example;
