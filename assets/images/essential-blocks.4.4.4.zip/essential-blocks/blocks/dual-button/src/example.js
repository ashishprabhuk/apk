const Example = {
	attributes: {
		showConnector: "true",
		buttonOneBorderShadowRds_Top: 20,
		buttonOneBorderShadowRds_Bottom: 0,
		buttonOneBorderShadowRds_Left: 20,
		buttonOneBorderShadowRds_Right: 0,
		buttonTwoBorderShadowRds_Top: 0,
		buttonTwoBorderShadowRds_Bottom: 20,
		buttonTwoBorderShadowRds_Left: 0,
		buttonTwoBorderShadowRds_Right: 20,
		buttonsGapRange: 0,
	}
};
export default Example;