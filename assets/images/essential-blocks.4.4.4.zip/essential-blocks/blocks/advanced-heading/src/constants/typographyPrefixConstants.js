// the consts defined here should be unique from one another
export const TITLE_TYPOGRAPHY = "title";
export const SUBTITLE_TYPOGRAPHY = "subtitle";