const example = {
	attributes: {
		// columnType: "default",
	},
};

export default example;
