const example = {
	attributes: {
		// layoutPreset: "preset2",
		// flexDirection: "column",
		// contentAlignment: "center",
	},
};

export default example;
