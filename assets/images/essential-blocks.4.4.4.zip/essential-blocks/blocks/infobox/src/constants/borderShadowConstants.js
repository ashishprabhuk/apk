export const wrpBdShadow = "wrp_";
export const btnBdShd = "btbds_";
