// each and every const here has to be totally unique from one another
export const infoWrapBg = "wrp_";
export const infoBtnBg = "btbg_";
