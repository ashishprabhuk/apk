// each and every const here has to be totally unique from one another

export const mediaBackground = "mediaBgSize";
export const mediaBgRadius = "mediaBgRadius";
export const mediaBgMargin = "mediaBgMargin";
export const buttonPadding = "buttonPadding";
// export const buttonRadius = "buttonRadius";

// 
export const buttonRadius = "buttonRadius";

// 

export const titlePadding = "titlePadding";
export const subTitlePadding = "subTitlePadding";
export const contentPadding = "contentPadding";
export const wrapperMargin = "wrapperMargin";
export const wrapperPadding = "wrapperPadding";
// export const wrp_border = "WRPborder";
// export const wrp_radius = "WRPradius";
