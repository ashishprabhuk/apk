const example = {
	attributes: {}
};
export default example;
