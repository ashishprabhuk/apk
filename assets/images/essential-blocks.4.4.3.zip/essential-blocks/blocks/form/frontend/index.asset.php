<?php return array('dependencies' => array(), 'version' => 'cda4a51a1cf704d2e900');
