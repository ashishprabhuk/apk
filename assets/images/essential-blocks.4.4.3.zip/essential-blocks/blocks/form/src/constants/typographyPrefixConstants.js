// each and every const here has to be totally unique from one another

export const FIELDS_TEXT = "fields_";
export const LABEL_TYPOGRAPHY = "label_";
export const BTN_TEXT = "btnText_";
export const SUCCESS_TYPO = "successText_";
export const ERROR_TYPO = "errorText_";
export const RADIO_TEXT = "radioText_";
export const CHECKBOX_TEXT = "checkboxText_";
export const FIELDS_TEXT_VALIDATION = "validationText_";
