// the consts defined here should be unique from one another
export const dimensionsMargin = "margin";
export const dimensionsPadding = "padding";
export const buttonPadding = "btn_padding";
export const frontIconMargin = "front_icon_margin";
export const frontIconPadding = "front_icon_padding";
export const backIconMargin = "back_icon_margin";
export const backIconPadding = "back_icon_padding";
export const frontTitlePadding = "frontTitlePadding";
export const backTitlePadding = "backTitlePadding";
export const frontContentPadding = "frontContentPadding";
export const backContentPadding = "backContentPadding";
export const frontImgPadding = "frontImgPadding";
export const backImgPadding = "backImgPadding";
export const frontItemPadding = "frontItemPadding";
export const backItemPadding = "backItemPadding";
