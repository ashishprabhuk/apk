export const borderShadow = "front_";
export const borderShadowBtn = "btn_";
export const borderShadowFrontIcon = "front_icon_";
export const borderShadowBackIcon = "back_icon_";
