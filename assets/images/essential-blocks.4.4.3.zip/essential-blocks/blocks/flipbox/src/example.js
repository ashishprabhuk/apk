const example = {
	attributes: {
		selectedSide: "front",
		frontIconOrImage: "icon",
		frontIcon: "fab fa-rev",
		frontTitle: "Front Title Here",
		frontContent: "Front Content Here"
	}
};

export default example;
