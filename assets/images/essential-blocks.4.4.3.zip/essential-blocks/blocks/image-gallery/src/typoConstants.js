export const CAPTION_TYPOGRAPHY = "captionTypo";
export const FILTER_TYPOGRAPHY = "filterTypo";
