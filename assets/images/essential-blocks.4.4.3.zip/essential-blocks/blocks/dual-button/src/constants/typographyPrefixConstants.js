// the consts defined here should be unique from one another
export const BUTTONS_TYPOGRAPHY = "button";
export const BUTTONS_CONNECTOR_TYPOGRAPHY = "button_connector";