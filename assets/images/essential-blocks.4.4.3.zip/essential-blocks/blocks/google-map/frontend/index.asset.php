<?php return array('dependencies' => array('wp-i18n'), 'version' => '8785da3597c641c54e78');
