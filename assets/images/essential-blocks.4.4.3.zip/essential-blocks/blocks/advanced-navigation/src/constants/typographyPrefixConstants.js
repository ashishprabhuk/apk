// each and every const here has to be totally unique from one another

export const typoPrefixNav = "nav_";
export const typoPrefixNavDropdown = "navDropdown_";
export const typoPrefixNavHamburger = "navHamburger_";
export const typoPrefixHamburgerBtn = "navHamburgerBtn_";
