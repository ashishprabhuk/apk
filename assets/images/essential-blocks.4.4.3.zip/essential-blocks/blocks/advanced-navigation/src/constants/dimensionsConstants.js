// each and every const here has to be totally unique from one another

export const prefixWrapperMargin = "wrpM_";
export const prefixWrapperPadding = "wrpP_";
export const prefixNavPadding = "navP_";
export const prefixNavMargin = "navM_";
export const prefixNavDropdownMargin = "dropdownM_";
export const prefixNavHamburgerPadding = "hamburgerP_";
export const prefixHamburgerItemPadding = "hamburgerItemP_";
export const prefixNavDropdownPadding = "dropdownP_";
export const prefixDropdownItemPadding = "dropdownItemP_";
export const prefixTtlWrpMargin = "ttlWM_";
export const prefixTtlWrpPadding = "ttlWP_";
export const prefixHamburgerBtnPadding = "hamburgerBtnP_";
