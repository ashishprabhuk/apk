export const prefixTitleMinWidth = "ttlMinW_";
export const prefixIconSize = "iconZ_";
export const prefixIconGap = "iconGap_";
export const prefixCaretSize = "carZ_";
export const prefixDropdownWidth = "dropdownW_";
export const prefixHamburerBtnSize = "hamburgerBtnZ_";
