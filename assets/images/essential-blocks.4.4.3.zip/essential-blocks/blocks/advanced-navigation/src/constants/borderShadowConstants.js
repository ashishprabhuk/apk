export const prefixWrapBdShadow = "wrpBds_";
export const prefixNavBdShadow = "navBds_";
export const prefixNavDropdownBdShadow = "navDropdownBds_";
export const prefixHamburgerItemBdShadow = "navHamburgerItemBds_";
export const prefixDropdownItemBdShadow = "dropdownItemBds_";
export const prefixActNavBdShadow = "actNavBds_";
export const prefixContentBdShadow = "conBds_";
export const prefixTtlWrpBdShadow = "ttlWBds_";
