// each and every const here has to be totally unique from one another

export const WrpBdShadowConst = "wrpBdSd_";
export const iconBdShadowConst = "icnBdSd_";
export const tabBdShadowConst = "tabBdSd_";
export const conBdShadowConst = "conBdSd_";
