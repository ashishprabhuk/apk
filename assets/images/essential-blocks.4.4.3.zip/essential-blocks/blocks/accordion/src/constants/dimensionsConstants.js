// each and every const here has to be totally unique from one another

export const wrapMarginConst = "wrpMrg_";
export const wrapPaddingConst = "wrpPad_";
export const iconMarginConst = "icnMrg_";
export const iconPaddingConst = "icnPad_";
export const tabMarginConst = "tabMrg_";
export const tabPaddingConst = "tabPad_";
export const conMarginConst = "conMrg_";
export const conPaddingConst = "conPad_";
