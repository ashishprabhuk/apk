// each and every const here has to be totally unique from one another

export const wrapperWidth = "wrpW_";
export const rangeIconSize = "icnZ_";
export const accGapRange = "acGp_";
