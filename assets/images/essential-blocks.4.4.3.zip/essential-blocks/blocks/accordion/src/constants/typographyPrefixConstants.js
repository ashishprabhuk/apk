// each and every const here has to be totally unique from one another

export const typoPrefix_title = "typTl_";
export const typoPrefix_content = "typCn_";
