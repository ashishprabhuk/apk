<?php return array('dependencies' => array(), 'version' => '5ad3f118798f8ca22497');
