export const typoPrefix_label = "label";
export const typoPrefix_input = "inpTxt";
export const typoPrefix_section_break = "sectionBreak";
export const typoPrefix_section_break_desc = "sectionBreakDesc";
export const typoPrefix_custom_html = "html";
export const typoPrefix_submit_btn = "subBtn";
export const typoPrefix_success = "success";
export const typoPrefix_error = "error";
