const example = {};

export default example;
