const example = {
	attributes: {
		buttonText: "Submit",
	},
};

export default example;
