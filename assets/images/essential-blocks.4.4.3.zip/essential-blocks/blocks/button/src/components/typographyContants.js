export const typoPrefix_text = "text";
