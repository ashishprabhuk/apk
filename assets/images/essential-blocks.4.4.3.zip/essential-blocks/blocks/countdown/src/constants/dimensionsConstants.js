// each and every const here has to be totally unique from one another

export const cdBoxsPaddingConst = "boxsP_";
export const cdWrapMarginConst = "wrpMrg_";
export const cdWrapPaddingConst = "wrpPad_";
export const cdDigitsPaddingConst = "dgPad_";
export const cdLabelsPaddingConst = "lblPad_";
