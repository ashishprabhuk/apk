// each and every const here has to be totally unique from one another

export const cdBoxsBgConst = "boxsBg_";
export const cdDayBoxBgConst = "dayBg_";
export const cdHourBoxBgConst = "hourBg_";
export const cdMinuteBoxBgConst = "minuteBg_";
export const cdSecondBoxBgConst = "secondBg_";
export const WrpBgConst = "WrpBg_";
