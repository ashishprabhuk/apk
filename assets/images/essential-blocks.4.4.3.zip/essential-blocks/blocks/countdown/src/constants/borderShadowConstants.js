// each and every const here has to be totally unique from one another

export const cdBoxsBdShadowConst = "boxsBds_";
export const WrpBdShadowConst = "wrpBdSd_";
