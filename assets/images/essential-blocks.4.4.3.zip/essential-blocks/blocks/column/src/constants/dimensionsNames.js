export const cWrapMarginConst = "colMrg_";
export const cWrapPaddingConst = "colPad_";
