export const WrpBdShadowConst = "colBdS_";
