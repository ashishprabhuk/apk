export const wrapperWidth = "cw_";
export const columnOrderPrefix = "colOrder_";