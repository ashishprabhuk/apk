// each and every const here has to be totally unique from one another

export const LABEL_TYPOGRAPHY = "label_";
export const FIELD_TEXT_VALIDATION = "validationText_";
export const FIELD_TEXT = "field_";
