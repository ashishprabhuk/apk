<?php return array('dependencies' => array('react', 'wp-element'), 'version' => '226c077ce192720f7303');
