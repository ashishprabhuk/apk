// each and every const here has to be totally unique from one another
export const prefixWrapBg = "wrpBg_";
export const prefixTitleBg = "ttlBg_";
export const prefixActTitleBg = "actTlBg_";
export const prefixContentBg = "conBg_";
export const prefixTtlWrpBg = "ttlWBg_";
