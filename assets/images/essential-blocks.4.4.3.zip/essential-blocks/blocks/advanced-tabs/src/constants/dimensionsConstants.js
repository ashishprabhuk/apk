// each and every const here has to be totally unique from one another

export const prefixWrapperMargin = "wrpM_";
export const prefixWrapperPadding = "wrpP_";
export const prefixTitlePadding = "ttlP_";
export const prefixTitleMargin = "ttlM_";
export const prefixContentMargin = "conM_";
export const prefixContentPadding = "conP_";
export const prefixTtlWrpMargin = "ttlWM_";
export const prefixTtlWrpPadding = "ttlWP_";
