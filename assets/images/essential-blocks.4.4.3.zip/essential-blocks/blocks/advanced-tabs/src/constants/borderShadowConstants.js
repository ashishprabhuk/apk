export const prefixWrapBdShadow = "wrpBds_";
export const prefixTitleBdShadow = "ttlBds_";
export const prefixActTitleBdShadow = "actTlBds_";
export const prefixContentBdShadow = "conBds_";
export const prefixTtlWrpBdShadow = "ttlWBds_";
