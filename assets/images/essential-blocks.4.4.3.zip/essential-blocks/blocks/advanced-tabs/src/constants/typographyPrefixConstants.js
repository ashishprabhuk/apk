// each and every const here has to be totally unique from one another

export const typoPrefixTabTitle = "title_";
