export const prefixTitleMinWidth = "ttlMinW_";
export const prefixIconSize = "iconZ_";
export const prefixIconGap = "iconGap_";
export const prefixCaretSize = "carZ_";
