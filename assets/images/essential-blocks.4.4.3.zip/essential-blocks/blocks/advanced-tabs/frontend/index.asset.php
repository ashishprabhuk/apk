<?php return array('dependencies' => array(), 'version' => 'e145e0d9f129f58d20b9');
