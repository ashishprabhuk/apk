import React from "react";

import { __ } from "@wordpress/i18n";

import Checkbox from "./Checkbox";

export default function Blocks() {
	return (
		<div>
			<Checkbox />
		</div>
	);
}
